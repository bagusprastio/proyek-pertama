-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Okt 2022 pada 08.50
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

DELIMITER $$
--
-- Prosedur
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_buku` (IN `judul` VARCHAR(100))   SELECT * FROM tbl_buku WHERE tbl_buku.buku_judul LIKE judul$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_member` (IN `nama_member` VARCHAR(50))   SELECT * FROM member WHERE member.member_nama LIKE judul$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_peminjaman` (IN `idbuku` INT(11))   SELECT * FROM peminjaman WHERE peminjaman.buku_id LIKE idbuku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_pustakawan` (IN `nama_pustakawan` VARCHAR(50))   SELECT * FROM pustakawan WHERE pustakawan.pustakawan_nama LIKE judul$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_buku` (IN `idbuku` INT(11))   DELETE FROM tbl_buku WHERE tbl_buku.buku_id=idbuku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_member` (IN `idmember` INT(11))   DELETE FROM member WHERE member.member_id=idmember$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_peminjaman` (IN `id_pinjam` INT(11))   DELETE FROM peminjaman WHERE peminjaman.pinjam_id=id_pinjam$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_pustakawan` (IN `idpustakawan` INT(11))   DELETE FROM pustakawan WHERE pustakawan.pustakawan_id=idpustakawan$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_buku` (IN `judul_buku` VARCHAR(100), IN `tgl_stok` DATE, IN `jumlah_buku` INT(10))   INSERT INTO tbl_buku (tbl_buku.buku_judul,tbl_buku.buku_tgl_stok,tbl_buku.buku_jumlah) VALUES (judul_buku,tgl_stok,jumlah_buku)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_member` (IN `nama_member` VARCHAR(11), IN `jenis_member` ENUM('L','P'), IN `tempat_lahir` TEXT, IN `tgl_lahir` DATE, IN `hp_member` CHAR(13))   INSERT INTO member (member.member_nama,member.member_jenis,member.member_tempat_lahir,member.member_tgl_lahir,member.member_hp)
VALUES (nama_member,jenis_member,tempat_lahir,tgl_lahir,hp_member)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_peminjaman` (IN `tgl_pinjam` DATE, IN `jumlah_pinjam` INT(3), IN `tgl_kembali` DATE, IN `jumlah_kembali` INT(3), IN `lama_pinjam` INT(2), IN `terlambat_pinjam` INT(2), IN `denda_pinjam` BIGINT(20), IN `id_buku` INT(11), IN `id_member` INT(11), IN `id_pustakawan` INT(11))   INSERT INTO peminjaman (peminjaman.pinjam_tgl,peminjaman.pinjam_jumlah,peminjaman.pinjam_kembali_tgl,
peminjaman.pinjam_kembali_jumlah,peminjaman.pinjam_lama_pinjam,peminjaman.pinjam_terlambat,peminjaman.pinjam_denda,
peminjaman.buku_id,peminjaman.member_id,peminjaman.pustakawan_id) VALUES 
(tgl_pinjam,jumlah_pinjam,tgl_kembali,jumlah_kembali,lama_pinjam,terlambat_pinjam,denda_pinjam,id_buku,id_member,id_pustakawan)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_pustakawan` (IN `nama_pustakawan` VARCHAR(50), IN `jenis_pustakawan` ENUM('L','P'), IN `alamat_pustakawan` TEXT, IN `hp_pustakawan` CHAR(13), IN `username_pustakawan` VARCHAR(50), IN `password_pustakawan` VARCHAR(50))   INSERT INTO pustakawan (pustakawan.pustakawan_nama,pustakawan.pustakawan_jenis,pustakawan.pustakawan_alamat,pustakawan.pustakawan_hp,
                        pustakawan.pustakawan_username,pustakawan.pustakawan_password)
VALUES (nama_pustakawan,jenis_pustakawan,alamat_pustakawan,hp_pustakawan,username_pustakawan,password_pustakawan)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_buku` ()   SELECT * FROM tbl_buku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_member` ()   SELECT * FROM member$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_peminjaman` ()   SELECT buku.*,member.*,pustakawan.*,peminjaman.* FROM buku,member,pustakawan,peminjaman WHERE buku.buku_id=peminjaman.buku_id AND member.member_id=peminjaman.member_id AND pustakawan.pustakawan_id=peminjaman.pustakawan_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_pustakawan` ()   SELECT * FROM pustakawan$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_buku` (IN `idbuku` INT(11), IN `judul_buku` VARCHAR(100), IN `tgl_stok` DATE, IN `jumlah_buku` INT(10))   UPDATE tbl_buku SET tbl_buku.buku_judul=judul_buku,tbl_buku.buku_tgl_stok=tgl_stok,tbl_buku.buku_jumlah=jumlah_buku WHERE
tbl_buku.buku_id=idbuku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_member` (IN `idmember` INT(11), IN `nama_member` INT(50), IN `jenis_member` ENUM('L','P'), IN `tempat_lahir` VARCHAR(100), IN `tgl_lahir` DATE, IN `hp_member` CHAR(13))   UPDATE member SET member.member_nama=nama_member,member.member_jenis=jenis_member,member.member_tempat_lahir=tempat_lahir,
member.member_tgl_lahir=tgl_lahir,member.member_hp=hp_member WHERE member.member_id=idmember$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_peminjaman` (IN `id_pinjam` MEDIUMINT(15), IN `tgl_pinjam` DATE, IN `jumlah_pinjam` INT(3), IN `tgl_kembali` DATE, IN `jumlah_kembali` INT(3), IN `lama_pinjam` INT(2), IN `terlambat_pinjam` INT(2), IN `denda_pinjam` BIGINT(20), IN `id_buku` INT(11), IN `id_member` INT(11), IN `id_pustakawan` INT(11))   UPDATE peminjaman SET
peminjaman.pinjam_tgl=tgl_pinjam,peminjaman.pinjam_jumlah=jumlah_pinjam,peminjaman.pinjam_kembali_tgl=tgl_kembali,peminjaman.pinjam_kembali_jumlah=jumlah_kembali,
peminjaman.pinjam_lama_pinjam=lama_pinjam,peminjaman.pinjam_terlambat=terlambat_pinjam,peminjaman.pinjam_denda=denda_pinjam,
peminjaman.buku_id=id_buku,peminjaman.member_id=id_member,peminjaman.pustakawan_id=id_pustakawan WHERE peminjaman.pinjam_id=id_pinjam$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_pustakawan` (IN `id_pustakawan` INT(11), IN `nama_pustakawan` VARCHAR(50), IN `jenis_pustakawan` ENUM('L','P'), IN `alamat_pustakawan` TEXT, IN `hp_pustakawan` CHAR(13), IN `username_pustakawan` VARCHAR(50), IN `password_pustakawan` VARCHAR(50))   UPDATE pustakawan SET pustakawan.pustakawan_nama=nama_pustakawan,pustakawan.pustakawan_jenis=jenis_pustakawan,pustakawan.pustakawan_alamat=alamat_pustakawan,pustakawan.pustakawan_hp=hp_pustakawan,
pustakawan.pustakawan_username=username_pustakawan,pustakawan.pustakawan_password=password_pustakawan WHERE pustakawan.pustakawan_id=id_pustakawan$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `member_id` int(11) NOT NULL,
  `member_nama` varchar(50) NOT NULL,
  `member_jenis` enum('L','P') NOT NULL,
  `member_tempat_lahir` varchar(100) NOT NULL,
  `member_tgl_lahir` date NOT NULL,
  `member_hp` char(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`member_id`, `member_nama`, `member_jenis`, `member_tempat_lahir`, `member_tgl_lahir`, `member_hp`) VALUES
(3, 'Badel iciki', 'L', 'Brayo barat', '1945-01-01', '0987654321');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `pinjam_id` mediumint(15) NOT NULL,
  `pinjam_tgl` date NOT NULL,
  `pinjam_jumlah` int(3) NOT NULL,
  `pinjam_kembali_tgl` date DEFAULT NULL,
  `pinjam_kembali_jumlah` int(3) DEFAULT NULL,
  `pinjam_lama_pinjam` int(2) DEFAULT NULL,
  `pinjam_terlambat` int(2) DEFAULT NULL,
  `pinjam_denda` bigint(20) DEFAULT NULL,
  `buku_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `pustakawan_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pustakawan`
--

CREATE TABLE `pustakawan` (
  `pustakawan_id` int(11) NOT NULL,
  `pustakawan_nama` varchar(50) NOT NULL,
  `pustakawan_jenis` enum('L','P') NOT NULL,
  `pustakawan_alamat` text NOT NULL,
  `pustakawan_hp` char(13) NOT NULL,
  `pustakawan_username` varchar(50) NOT NULL,
  `pustakawan_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pustakawan`
--

INSERT INTO `pustakawan` (`pustakawan_id`, `pustakawan_nama`, `pustakawan_jenis`, `pustakawan_alamat`, `pustakawan_hp`, `pustakawan_username`, `pustakawan_password`) VALUES
(1, 'Badel ', 'L', 'brayo', '0895678899', 'slebew', '12345');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_buku`
--

CREATE TABLE `tbl_buku` (
  `buku_id` int(11) NOT NULL,
  `buku_judul` varchar(100) NOT NULL,
  `buku_tgl_stok` date NOT NULL,
  `buku_jumlah` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`member_id`);

--
-- Indeks untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`pinjam_id`),
  ADD KEY `buku_id` (`buku_id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `pustakawan_id` (`pustakawan_id`);

--
-- Indeks untuk tabel `pustakawan`
--
ALTER TABLE `pustakawan`
  ADD PRIMARY KEY (`pustakawan_id`);

--
-- Indeks untuk tabel `tbl_buku`
--
ALTER TABLE `tbl_buku`
  ADD PRIMARY KEY (`buku_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `member`
--
ALTER TABLE `member`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `pinjam_id` mediumint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pustakawan`
--
ALTER TABLE `pustakawan`
  MODIFY `pustakawan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tbl_buku`
--
ALTER TABLE `tbl_buku`
  MODIFY `buku_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`pustakawan_id`) REFERENCES `pustakawan` (`pustakawan_id`),
  ADD CONSTRAINT `peminjaman_ibfk_3` FOREIGN KEY (`buku_id`) REFERENCES `tbl_buku` (`buku_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
